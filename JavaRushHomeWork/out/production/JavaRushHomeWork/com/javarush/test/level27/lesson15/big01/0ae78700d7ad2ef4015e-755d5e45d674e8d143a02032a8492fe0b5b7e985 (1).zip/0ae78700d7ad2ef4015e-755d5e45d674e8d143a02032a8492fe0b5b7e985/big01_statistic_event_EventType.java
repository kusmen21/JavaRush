package com.javarush.test.level27.lesson15.big01.statistic.event;

/**
 * Created by FarAway on 28.02.2016.
 */
public enum EventType {
    COOKED_ORDER,
    SELECTED_VIDEOS,
    NO_AVAILABLE_VIDEO;
}
