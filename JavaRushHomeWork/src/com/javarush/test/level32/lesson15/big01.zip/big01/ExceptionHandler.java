package com.javarush.test.level32.lesson15.big01;


public class ExceptionHandler
{
    public static void log(Exception e)
    {
        System.out.println(e.toString());
    }
}
