package com.javarush.test.level32.lesson15.big01.listeners;


public class UndoListener
{
}
