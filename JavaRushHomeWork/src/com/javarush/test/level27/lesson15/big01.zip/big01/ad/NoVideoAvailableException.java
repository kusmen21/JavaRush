package com.javarush.test.level27.lesson15.big01.ad;


public class NoVideoAvailableException extends RuntimeException {
}